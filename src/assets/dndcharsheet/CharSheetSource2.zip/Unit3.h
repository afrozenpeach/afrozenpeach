//---------------------------------------------------------------------------

#ifndef Unit3H
#define Unit3H
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <ComCtrls.hpp>
#include "CSPIN.h"
//---------------------------------------------------------------------------
class TForm3 : public TForm
{
__published:	// IDE-managed Components
        TListBox *Rolls;
        TListBox *StatTypes;
        TButton *RollStats;
        TLabel *Label1;
        TEdit *NumberofRolls;
        TLabel *Label2;
        TLabel *Label3;
        TLabel *Label4;
        TLabel *Label5;
        TLabel *Label6;
        TLabel *Label7;
        TLabel *StrRoll;
        TLabel *DexRoll;
        TLabel *ConRoll;
        TLabel *IntRoll;
        TLabel *WisRoll;
        TLabel *ChaRoll;
        TLabel *Label8;
        TEdit *Rerolls1;
        TLabel *Label9;
        TEdit *PointsLeft;
        TCheckBox *NoRerollifDrop;
        TButton *Reset;
        TButton *Apply;
        TButton *Close;
        TLabel *Label10;
        TLabel *PointsSpent;
        TEdit *Rerolls2;
        TCSpinButton *CSpinButton1;
        void __fastcall StatTypesClick(TObject *Sender);
        void __fastcall ResetClick(TObject *Sender);
        void __fastcall ApplyClick(TObject *Sender);
        void __fastcall RollStatsClick(TObject *Sender);
        void __fastcall CSpinButton1DownClick(TObject *Sender);
        void __fastcall CSpinButton1UpClick(TObject *Sender);
        void __fastcall FormShow(TObject *Sender);
private:	// User declarations
public:		// User declarations
        __fastcall TForm3(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TForm3 *Form3;
//---------------------------------------------------------------------------
#endif
